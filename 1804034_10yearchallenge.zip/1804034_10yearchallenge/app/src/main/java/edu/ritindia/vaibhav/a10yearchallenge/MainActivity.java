package edu.ritindia.vaibhav.a10yearchallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText login ,passwd;
    Button loginbtn1, canclebtn1;
    Spinner spinner1;
    ArrayAdapter <String> arrayAdapter;
    String Role[]={"Student","Faculty","Lab Assistance"};
    String Student_ID[]={"1804034","abc"};
    String Faculty_ID[]={"RJM","RJM"};
    String LabA_ID[]={"lab","lab"};
    String status;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login =findViewById(R.id.userid);
        passwd=findViewById(R.id.password);
        loginbtn1=findViewById(R.id.loginbtn);
        canclebtn1=findViewById(R.id.canclebtn);
        spinner1=findViewById(R.id.spinner);
        arrayAdapter=new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_item,Role);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(arrayAdapter);



        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                status=Role[position];

                    Toast.makeText(getApplicationContext(),Role[position],Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

                Toast.makeText(getApplicationContext(),"Nothing Selected",Toast.LENGTH_LONG).show();

            }


        });

        loginbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String id,nm;
                id=login.getText().toString();
                nm=passwd.getText().toString();

                if (status=="Student") {
                    if (Student_ID[0].equals(id)&&Student_ID[1].equals(nm)) {
                        Intent i = new Intent(MainActivity.this, student.class);
                        startActivity(i);
                    }
                }

                if (status=="Faculty")
                {
                    if (Faculty_ID[0].equals(id)&&Faculty_ID[1].equals(nm)) {

                        Intent i1=new Intent(MainActivity.this,faculty.class);
                        startActivity(i1);
                    }

                }

                if (status=="Lab Assistance")
                {
                    if (LabA_ID[0].equals(id)&&LabA_ID[1].equals(nm))
                    {
                        Intent i2=new Intent(MainActivity.this,labAssistant.class);
                        startActivity(i2);
                    }

                }


                }



        });

               canclebtn1.setOnClickListener(new View.OnClickListener() {
                   @Override
                   public void onClick(View v) {

                       login.setText("");
                       passwd.setText("");

                   }
               });








    }
}
package edu.rit.vaibhav.mycalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText eTextNum1 , eTextNum2 ;
    Button add , sub , multiply , divide ;
    TextView tAns ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        eTextNum1 = findViewById(R.id.eTextNumber1);
        eTextNum2 = findViewById(R.id.eTextNumber2);
        tAns = findViewById(R.id.textAnswer);
        add = findViewById(R.id.buttonAdd);
        sub = findViewById(R.id.buttonSub);
        multiply = findViewById(R.id.buttonMultiply);
        divide = findViewById(R.id.buttonDivide);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num1 , num2 , ans ;
                num1= Integer.parseInt(eTextNum1.getText().toString());
                num2= Integer.parseInt(eTextNum2.getText().toString());
                ans = num1 + num2 ;

                tAns.setText("Answer is "+ans);

            }
        });

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int num1 , num2 , ans ;
                num1 =Integer.parseInt(eTextNum1.getText().toString());
                num2 =Integer.parseInt(eTextNum2.getText().toString());
                ans = num1 - num2 ;
                tAns.setText("Answer is "+ans);
            }
        });


        multiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int num1 , num2 , ans ;
                num1 =Integer.parseInt(eTextNum1.getText().toString());
                num2 =Integer.parseInt(eTextNum2.getText().toString());
                ans = num1 * num2 ;
                tAns.setText("Answer is "+ans);
            }
        });


        divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int num1 , num2 , ans ;
                num1 =Integer.parseInt(eTextNum1.getText().toString());
                num2 =Integer.parseInt(eTextNum2.getText().toString());
                ans = num1 / num2 ;
                tAns.setText("Answer is "+ans);
            }
        });

    }
}
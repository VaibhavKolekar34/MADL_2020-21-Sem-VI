package edu.ritindia.vaibhav.quizapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    RadioGroup radioGroup;
    RadioButton radioButton;
    FloatingActionButton floatingActionButton;
    int count=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        textView=findViewById(R.id.textView1);
        radioGroup=findViewById(R.id.radioGroup1);
        floatingActionButton=findViewById(R.id.floatingActionButton1);

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id =radioGroup.getCheckedRadioButtonId();
                radioButton=findViewById(id);

              /*  switch (id)
                {
                    case R.id.radioButton1:
                        Toast.makeText(getApplicationContext(),radioButton.getText().toString(),Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton2:
                        Toast.makeText(getApplicationContext(),radioButton.getText().toString(),Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton3:
                        Toast.makeText(getApplicationContext(),radioButton.getText().toString(),Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton4:
                        Toast.makeText(getApplicationContext(),radioButton.getText().toString(),Toast.LENGTH_LONG).show();
                        break;
                }*/

                if(id==R.id.radioButton2)
                {
                    Snackbar.make(v,"Answer is True MARKS=1",Snackbar.LENGTH_LONG).setAction("NEXT", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            count++;
                            Intent i=new Intent(MainActivity.this,Second_que.class);
                            i.putExtra("count",count);
                            startActivity(i);

                        }
                    }).show();
                }
                else
                {
                    Snackbar.make(v,"Answer is Wrong MARKS=0",Snackbar.LENGTH_LONG).setAction("NEXT", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent i1=new Intent(MainActivity.this,Second_que.class);
                            startActivity(i1);
                        }
                    }).show();
                }



            }
        });


    }
}
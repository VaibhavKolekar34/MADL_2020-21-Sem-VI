package edu.ritindia.vaibhav.a10yearchallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class labAssistant extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab_assistant);

        ImageView img3;
        Button btn5,btn6;

        btn5=findViewById(R.id.button5);
        btn6=findViewById(R.id.button6);
        img3=findViewById(R.id.imageView3);

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                img3.setImageResource(R.drawable.lab_now);

            }
        });

        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i4=new Intent(labAssistant.this,MainActivity.class);
                startActivity(i4);
            }
        });

    }
}
package edu.ritindia.vaibhav.a10yearchallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class faculty extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty);

        ImageView img;
        Button btn3,btn4;

       btn3=findViewById(R.id.button3);
       btn4=findViewById(R.id.button4);
       img=findViewById(R.id.imageView2);

       btn3.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

               img.setImageResource(R.drawable.faculty_now);

           }
       });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i3=new Intent(faculty.this,MainActivity.class);
                startActivity(i3);
            }
        });
    }
}
package edu.ritindia.vaibhav.quizapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class Second_que extends AppCompatActivity {

    TextView textView;
    RadioButton radioButton;
    RadioGroup radioGroup;
    FloatingActionButton floatingActionButton;

    int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_que);
      //  textView=findViewById(R.id.textView2);
        radioGroup=findViewById(R.id.radioGroup2);

        floatingActionButton=findViewById(R.id.floatingActionButton2);
        Intent i1=getIntent();
        count=i1.getIntExtra("count",0);

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id=radioGroup.getCheckedRadioButtonId();
                radioButton=findViewById(id);

                /*
                switch (id)

                {
                    case R.id.radioButton5:
                        Toast.makeText(getApplicationContext(),radioButton.getText().toString(),Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton6:
                        Toast.makeText(getApplicationContext(),radioButton.getText().toString(),Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton7:
                        Toast.makeText(getApplicationContext(),radioButton.getText().toString(),Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton8:
                        Toast.makeText(getApplicationContext(),radioButton.getText().toString(),Toast.LENGTH_LONG).show();
                        break;
                }
                */

                if(id==R.id.radioButton5)
                {
                    Snackbar.make(v,"Ans is True MARKS=1",Snackbar.LENGTH_LONG).setAction("NEXT", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            count++;
                            Intent i2=new Intent(Second_que.this,Third_que.class);
                            i2.putExtra("count",count);
                            startActivity(i2);

                        }
                    }).show();
                }
                else {
                    Snackbar.make(v,"Ans is Wrong MARKS=0",Snackbar.LENGTH_LONG).setAction("NEXT", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent i11 =new Intent(Second_que.this,Third_que.class);
                            i11.putExtra("count",count);
                            startActivity(i11);
                        }
                    }).show();
                }

            }
        });

    }
}
package edu.ritindia.vaibhav.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView text1, text2,text3,text;
        EditText weight,height;
        Button btn;

        text1 =findViewById(R.id.tv1);
        text2 =findViewById(R.id.tv2);
        text3 =findViewById(R.id.tv3);
        text =findViewById(R.id.tv);
        btn=findViewById(R.id.button);
        weight=findViewById(R.id.editTextNumberDecimal);
        height=findViewById(R.id.editTextNumberDecimal2);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String wgt ,hgt;
                wgt=weight.getText().toString();
                hgt=height.getText().toString();
                float weight1=Float.parseFloat(wgt);
                float height1=Float.parseFloat(hgt);

                float bmi=(weight1)/((height1)*(height1));

                String BMI=Float.toString(bmi);
                text3.setText("BMI IS "+bmi);

               // Toast.makeText(getApplicationContext(),"BMI IS " +bmi,Toast.LENGTH_LONG).show();
            }
        });

    }
}